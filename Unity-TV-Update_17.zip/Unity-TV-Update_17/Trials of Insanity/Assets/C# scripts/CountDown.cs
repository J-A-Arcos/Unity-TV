using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class CountDown : MonoBehaviour
{
    public string LevelToLoad;

    //[SerializeField] GameObject panel;
    [SerializeField] Image timeImage;
    [SerializeField] Text timeText;
    [SerializeField] float duration, currentTime;

    void Start()
    {
        //panel.SetActive(false);

        currentTime = duration;
        timeText.text = currentTime.ToString();
        StartCoroutine(TimeIEn());
    }

    IEnumerator TimeIEn()
    {
        while(currentTime >= 0)
        {
            timeImage.fillAmount = Mathf.InverseLerp(0, duration, currentTime);
            timeText.text = currentTime.ToString();
            yield return new WaitForSeconds(1f);
            currentTime--;
        }

        if (currentTime <= 0.001)
        {
            SceneManager.LoadScene(LevelToLoad);
        }

    }

    /*void Update()
    {
        if (currentTime <= 0.001)
        {
            SceneManager.LoadScene(LevelToLoad);
        }

    }*/


}
